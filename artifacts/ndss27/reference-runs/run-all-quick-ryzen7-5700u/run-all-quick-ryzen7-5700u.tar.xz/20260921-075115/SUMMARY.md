# microtaint NDSS 2027 artifact, run 20260921-075115

mode: quick (reduced corpus, NOT the paper numbers)
engine version: v0.7.2
MICROTAINT_TAINT_IR=0

avalanche-calibrate      PASS exit 0
avalanche-base64-debian12 PASS exit 0
avalanche-base64-static  PASS exit 0
avalanche-base64-system  PASS exit 0
avalanche-nftables       PASS exit 0
avalanche-siphash        PASS exit 0
rq7-bof                  PASS 1 bof finding(s) detected
rq7-uaf                  PASS 1 uaf finding(s) detected
rq7-sc                   PASS 1 side_channel finding(s) detected
rq7-aiw                  PASS 1 aiw finding(s) detected
rq7-crypto-check         PASS exit 0
rq7-crypto-localise      PASS exit 0
rq7-dns                  PASS exit 0
rq1-synthesis            PASS exit 0
rq7-other-angr           PASS exit 0
rq7-other-angr-loc       PASS exit 0
rq7-other-maat           PASS exit 0
rq7-other-maat-loc       PASS exit 0
rq7-other-triton         PASS exit 0
rq7-other-libdft         PASS exit 0
rq7-other-tgrind         PASS exit 0
rq7-other-panda          PASS exit 0
rq5-ladder               PASS exit 0
rq5-bench                PASS exit 0
rq2-soundness            PASS exit 0
rq3-precision            NOTE scored in the rq2 pass
rq4-per-step-cost        NOTE scored in the rq2 pass
rq6-pass1                PASS exit 0
rq6-pass2                PASS exit 0
macros-avalanche         PASS /home/jns/Documents/Telecom/PRIM/pcode-taint-engine/artifacts/ndss27/results/20260921-075115/avalanche_numbers.tex
macros-benchmark         PASS /home/jns/Documents/Telecom/PRIM/pcode-taint-engine/artifacts/ndss27/results/20260921-075115/benchmark_numbers.tex
figures                  PASS /home/jns/Documents/Telecom/PRIM/pcode-taint-engine/artifacts/ndss27/results/20260921-075115/fig_*.pdf
tables-eval              PASS /home/jns/Documents/Telecom/PRIM/pcode-taint-engine/artifacts/ndss27/results/20260921-075115/eval_tables.md
tables-ladder            PASS /home/jns/Documents/Telecom/PRIM/pcode-taint-engine/artifacts/ndss27/results/20260921-075115/ladder_table.md
tables-apps              PASS /home/jns/Documents/Telecom/PRIM/pcode-taint-engine/artifacts/ndss27/results/20260921-075115/apps_tables.md
tables-multiisa          SKIP table5 campaign not run (see rq6-generalisation/table5/)
